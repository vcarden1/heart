import streamlit as st


class TheHomePage:
    def __init__(self) -> None:
        # TODO: Define page-specific variables here
        pass

    def display(self):
        # TODO: define the streamlit view here
        st.header("Predicting Heart Desease")
