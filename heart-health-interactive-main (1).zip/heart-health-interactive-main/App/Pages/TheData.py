import streamlit as st


class TheDataPage:
    def __init__(self) -> None:
        # TODO: Define page-specific variables here
        pass

    def display(self):
        # TODO: define the streamlit view here
        st.header("About the Data")
