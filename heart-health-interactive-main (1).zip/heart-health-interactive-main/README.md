# heart-health-interactive
Cloud Computing for Data Analytics Final Project. This is an interactive app that can predict the risk an individual has of suffering from a heart attack, hosted and served from AWS.
